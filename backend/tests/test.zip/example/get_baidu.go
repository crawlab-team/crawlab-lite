package main

import (
	"fmt"
	"net/http"
)

func main() {
	resp, err := http.Get("https://www.baidu.com")
	if err != nil {
		fmt.Printf("error occurred while fetching page, error: %s", err.Error())
	}
	if resp != nil {
		defer resp.Body.Close()
	}
	fmt.Println("ok")
}
