#!/usr/bin/env bash 

echo "Hello Crawlab"
go run ./get_baidu.go
